const routes = {
  admin: {
    dashboard: "/",
    productManagement: "/admin/manage-products",
    userManagement: "/admin/manage-users",
  },
};

export default routes;
