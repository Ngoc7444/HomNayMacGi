import React from "react";
import AdminLayout from "../../../AdminLayout/DefaultLayout/AdminLayout";

const Dashboard = () => {
  return (
    <div>
      <AdminLayout />
    </div>
  );
};

export default Dashboard;
