import React from "react";
import DefaultLayout from "../../../layouts/DefaultLayout/DefaultLayout";
const Home = () => {
  return (
    <div>
      <DefaultLayout />
    </div>
  );
};

export default Home;
